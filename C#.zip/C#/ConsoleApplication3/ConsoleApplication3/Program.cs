﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            String myString = "This is my string";
            String newString="";

            for (int i = myString.Length -1 ; i >= 0; i--)
            {
                newString += myString[i];
            }

            Console.WriteLine(newString);

            Console.ReadKey();
        }
    }
}

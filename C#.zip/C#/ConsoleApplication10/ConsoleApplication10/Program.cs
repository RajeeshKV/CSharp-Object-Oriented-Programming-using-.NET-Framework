﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication10
{

    class Checker {
        private int a, b, c;
        public Checker(int a, int b, int c){
            this.a = a;
            this.b = b;
            this.c = c;
        }
        public void check() {
            if (a > b && a > c) {
                Console.WriteLine(a + " is the largest");
            }
            else if (b > c)
            {
                Console.WriteLine(b + " is the largest");
            }
            else {
                Console.WriteLine(c + " is the largest");
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Checker c = new Checker(5, 8, 3);
            c.check();
            Console.ReadKey();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication6
{
    public class A
    {
        public int a = 10;
        private int b = 20;
        protected int c = 30;
        internal int d = 40;

        public void dis()
        {
            Console.WriteLine(b);
        }
    }

    public class B : A
    {
        public void dis()
        {
            Console.WriteLine(c);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            B b = new B();

            Console.WriteLine(b.a);
            b.dis();

            A a = new A();

            a.dis();

            Console.WriteLine(a.d);

            Console.ReadKey();
        }
    }
}

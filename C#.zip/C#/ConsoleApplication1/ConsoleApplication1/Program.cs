﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            String Actual, left, right, middle;
            int len;
            Actual = "ThisIsTheActualString";
            len = Actual.Length;
            try
            {
                left = Actual.Substring(0, 5);
                right = Actual.Substring(len-5,5);
                middle = Actual.Substring(5, 5);

                Console.WriteLine("Left: " + left);
                Console.WriteLine("Right: " + right);
                Console.WriteLine("Middle: " + middle);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            Console.ReadKey();
        }
    }
}

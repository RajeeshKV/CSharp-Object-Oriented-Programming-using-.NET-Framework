﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication12
{
    public delegate void arithmetic_operation();
    public class Calculate
    {
        int num1, num2;
        public Calculate(int x, int y)
        {
            num1 = x;
            num2 = y;
        }
        public void Add()
        {
            Console.WriteLine("\nSUM = {0}", num1 + num2);
        }
        public void Sub()
        {
            Console.WriteLine("\nDIFFERENCE = {0}", num1 -
            num2);
        }
        public void Mul()
        {
            Console.WriteLine("\nPRODUCT = {0}", num1 *
            num2);
        }
        public void Div()
        {
            Console.WriteLine("\nQUOTIENT = {0}", num1 /
            num2);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            arithmetic_operation aop;
            Console.WriteLine("Enter two integers:");
            int num1 = Convert.ToInt32(Console.ReadLine());
            int num2 = Convert.ToInt32(Console.ReadLine());
            Calculate calc = new Calculate(num1, num2);
            Console.WriteLine("Enter the operation to be performed:");
            Console.WriteLine("Enter \t '+' for addition");
            Console.WriteLine("\t '-' for subtraction");
            Console.WriteLine("\t '*' for multiplication");
            Console.WriteLine("\t '/' for division");
            Console.WriteLine("\t 'a' for all the operations");
            Console.Write("Your choice : ");
            char c = Convert.ToChar(Console.ReadLine());
            if (c == '+')
                aop = new arithmetic_operation(calc.Add);
            else if (c == '-')
                aop = new arithmetic_operation(calc.Sub);
            else if (c == '*')
                aop = new arithmetic_operation(calc.Mul);
            else if (c == '/')
                aop = new arithmetic_operation(calc.Div);
            else if (c == 'a')
                aop = new arithmetic_operation(calc.Add) +
                new arithmetic_operation(calc.Sub) + new arithmetic_operation(calc.Mul) + new
                arithmetic_operation(calc.Div);
            else
                aop = null;
            //method calling
            aop();
            Console.ReadKey();
        }
    }
}

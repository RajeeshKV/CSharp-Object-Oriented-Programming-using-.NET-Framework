﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication5
{

   public abstract class Demo
    {
        public abstract void dis();
    }

   public class Real : Demo
    {
        public override void dis()
        {
            Console.WriteLine("Real class");
        }
    }
    public class Actual : Demo
    {
        public override void dis() {
            Console.WriteLine("Actual class");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Demo d;
            d = new Real();
            d.dis();

            d = new Actual();
            d.dis();

            Console.ReadKey();
        }
    }
}

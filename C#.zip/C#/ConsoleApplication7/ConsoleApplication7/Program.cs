﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication7
{
    public class Calculate
    {
        public void Area(int a, int b) {
            Console.WriteLine(a * b);
        }

        public void Area(int a) {
            Console.WriteLine(a * a);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Calculate c = new Calculate();

            c.Area(4, 5);
            c.Area(6);

            Console.ReadKey();
        }
    }
}

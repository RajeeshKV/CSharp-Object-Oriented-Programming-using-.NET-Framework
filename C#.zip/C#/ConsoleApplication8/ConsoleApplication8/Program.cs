﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication8
{
    class A
    {
        public void show(String name)
        {
            Console.WriteLine("Hello " + name);
        }
    }
    class B : A {
        public B()
        {
            Console.WriteLine("Hello World");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            B b = new B();
            b.show("Rajeesh");
            Console.ReadKey();
        }
    }
}

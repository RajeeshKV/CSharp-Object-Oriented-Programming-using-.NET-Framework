﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            String myString = "This is an example string";

            myString = myString.Replace("example", "model");

            Console.WriteLine(myString);

            Console.ReadKey();
        }
    }
}

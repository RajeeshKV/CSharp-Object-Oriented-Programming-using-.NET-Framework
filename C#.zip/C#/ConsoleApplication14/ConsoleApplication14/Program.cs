﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication14
{
    class Program
    {
        static void Main(string[] args)
        {
            int ch,ind;
            string name;
            customer customer1;
            List<customer> Customers = new List<customer>();
            do{
                Console.WriteLine("1. Insert");
                Console.WriteLine("2. Update");
                Console.WriteLine("3. Delete");
                Console.WriteLine("4. Display");
                Console.WriteLine("5. Exit");
                Console.Write("Select an option: ");
                ch = Convert.ToInt32(Console.ReadLine());
                switch (ch) {
                    case 1: Console.WriteLine("Enter name: ");
                            name = Console.ReadLine();
                            customer1 = new customer()
                            {
                                EmpName = name
                            };
                            Customers.Add(customer1);
                            break;
                    case 2: Console.WriteLine("Enter index: ");
                            ind = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Enter name: ");
                            name = Console.ReadLine();
                            Customers[ind].EmpName = name;
                            break;
                    case 3: Console.WriteLine("Enter index: ");
                            ind = Convert.ToInt32(Console.ReadLine());
                            Customers.RemoveAt(ind);
                            break;
                    case 4: foreach (customer c in Customers)
                            {
                                Console.WriteLine("Name={0}", c.EmpName);
                            }
                            break;
                    case 5: return;
                    default : Console.WriteLine("Invalid option");
                              break;
                }
            }while(ch>0);
           
            Console.ReadKey();
        }
    }
    class customer
    {
        public string EmpName { get; set; }
    }
}  

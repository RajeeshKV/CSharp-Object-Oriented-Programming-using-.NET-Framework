﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication9
{
    class Student {
        private string name;

        public string Name
        {
            get {
                return name;
            }
            set {
                name = value;
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Student s = new Student();

            s.Name = "Rajeesh";
            Console.WriteLine("Hello, " + s.Name);
            Console.ReadKey();
        }
    }
}

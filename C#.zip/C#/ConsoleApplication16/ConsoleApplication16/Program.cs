﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication16
{
    class Printer //can be inherited
    {
        public virtual void print()
        {
            Console.WriteLine("printer printing....\n");
        }
    }
    sealed class LaserJet : Printer //Cannot inherit this class
    {
        override public void print()
        {
            Console.WriteLine("Laserjet printer printing....\n");
        }
    }

    sealed class DeskJet : Printer //Cannot inherit this class
    {
        override public void print()
        {
            Console.WriteLine("Deskjet printer printing....\n");
        }
    } 

    class Program
    {
        static void Main(string[] args)
        {
            Printer p = new Printer();
            p.print();

            p = new LaserJet();
            p.print();

            p = new DeskJet();
            p.print();

            Console.ReadKey();
        }
    }
}

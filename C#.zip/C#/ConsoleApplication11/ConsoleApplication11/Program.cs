﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication11
{
    class ConstructDemo { 
        private string name;
        public ConstructDemo(string name)
        {
            this.name = name;
        }

        public void dis() {
            Console.WriteLine("Hello " + name);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            ConstructDemo c = new ConstructDemo("Rajeesh");
            c.dis();
            Console.ReadKey();
        }
    }
}

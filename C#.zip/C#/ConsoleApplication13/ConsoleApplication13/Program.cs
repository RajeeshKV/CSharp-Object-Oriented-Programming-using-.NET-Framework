﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication13
{
    class Program
    {
        static void Main(string[] args)
        {
            StringBuilder s = new StringBuilder("Hello ", 20);
            s.Append("Rajeesh.");
            s.Append("How are you?");

            Console.WriteLine(s);
            Console.ReadKey();
        }
    }
}

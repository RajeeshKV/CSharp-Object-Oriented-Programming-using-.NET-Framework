﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication4
{

    interface MyInterface
    {
        void dis();
    }

    class MyClass : MyInterface
    {
        public void dis()
        {
            Console.WriteLine("Hello world");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            MyInterface my = new MyClass();
            my.dis();
            Console.ReadKey();
        }
    }
}
